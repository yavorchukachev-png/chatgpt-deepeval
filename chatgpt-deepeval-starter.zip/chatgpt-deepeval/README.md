# ChatGPT DeepEval — free starter

This project checks sample AI answers using **DeepEval** and **pytest**, with no OpenAI API key or paid DeepEval account.

## Quick start

1. Upload the contents of this project to the root of your GitHub repository, preserving folders.
2. Open **Actions** → **Free AI answer checks** → **Run workflow**, or push a change.
3. A green check means the sample tests passed; it does **not** certify factual or legal accuracy.

## Run locally

```bash
python -m pip install -r requirements.txt
pytest -q
```

## Add an answer to test

Edit `examples/cases.json`: enter the question, answer, and phrases the answer must contain. The free checks confirm presence of required phrases only. They cannot establish that a statute is current, that a citation is real, or that a conclusion is legally sound. For source-grounded evaluation, a verified legal corpus and more sophisticated metrics are needed.

## Privacy and cost

Do not commit private conversations, API keys, client data, or sensitive documents to a public repository. GitHub-hosted Actions and third-party dependencies have their own usage terms and limits. These tests use no paid LLM API.

## Limitations

This repository does not automatically read your ChatGPT conversations or change the ChatGPT model, memory, or context window. Paste only the answers you explicitly choose to evaluate. DeepEval's judge-model metrics require additional setup and may incur costs.
