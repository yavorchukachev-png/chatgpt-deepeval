"""DeepEval smoke test using a deterministic custom metric (no paid judge)."""
from deepeval import assert_test
from deepeval.metrics import BaseMetric
from deepeval.test_case import LLMTestCase


class RequiredPhraseMetric(BaseMetric):
    def __init__(self, phrase: str):
        self.phrase = phrase
        self.threshold = 1.0
        self.score = 0.0
        self.reason = ''
        self.success = False

    def measure(self, test_case: LLMTestCase) -> float:
        self.success = self.phrase.casefold() in test_case.actual_output.casefold()
        self.score = 1.0 if self.success else 0.0
        self.reason = 'Required phrase found' if self.success else 'Required phrase missing'
        return self.score

    async def a_measure(self, test_case: LLMTestCase) -> float:
        return self.measure(test_case)

    def is_successful(self) -> bool:
        return self.success

    @property
    def __name__(self):
        return 'Required phrase (free deterministic)'


def test_deepeval_import_and_custom_metric():
    case = LLMTestCase(input='Какво урежда чл. 127 ГПК?', actual_output='Чл. 127 ГПК урежда съдържанието на исковата молба.')
    assert_test(case, [RequiredPhraseMetric('чл. 127 ГПК')])
