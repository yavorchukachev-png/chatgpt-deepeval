"""Free, deterministic checks: no API keys or LLM judge required."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CASES = json.loads((ROOT / 'examples' / 'cases.json').read_text(encoding='utf-8'))


def test_examples_have_required_fields():
    assert CASES, 'Add at least one test case'
    for case in CASES:
        assert all(case.get(k) for k in ('question', 'answer', 'required_terms'))


def test_required_terms_present():
    for case in CASES:
        answer = case['answer'].casefold()
        missing = [term for term in case['required_terms'] if term.casefold() not in answer]
        assert not missing, f"{case['question']}: missing {missing}"
